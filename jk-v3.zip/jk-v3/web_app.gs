// ============================================================
// JK MONEY TRACKER — Web App (doGet + doPost)
// Deploy as Web App:
//   Apps Script → Deploy → New Deployment → Web App
//   Execute as: Me | Who has access: Anyone
//   Copy the Web App URL → paste into index.html
// ============================================================

const SHEET_NAME  = 'Entries';
const DEBT_SHEET  = 'Debt Tracker';

// ── doGet — serve all data as JSON ──────────────────────────
function doGet(e) {
  try {
    const ss       = SpreadsheetApp.getActiveSpreadsheet();
    const entries  = getEntries(ss);
    const debts    = getDebts(ss);
    const summary  = getMonthlySummary(entries);
    const cats     = getCategorySummary(entries);

    const payload  = JSON.stringify({ entries, debts, summary, cats });
    return ContentService.createTextOutput(payload)
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({ error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ── doPost — save new entry or debt ─────────────────────────
function doPost(e) {
  try {
    const ss   = SpreadsheetApp.getActiveSpreadsheet();
    const data = JSON.parse(e.postData.contents);

    if (data.action === 'addEntry') {
      saveEntry(ss, data);
    } else if (data.action === 'addDebt') {
      saveDebt(ss, data);
    } else if (data.action === 'updateDebtStatus') {
      updateDebtStatus(ss, data);
    } else if (data.action === 'deleteEntry') {
      deleteEntry(ss, data);
    }

    return ContentService.createTextOutput(JSON.stringify({ success: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({ success: false, error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ── Read Entries ─────────────────────────────────────────────
function getEntries(ss) {
  const sheet  = ss.getSheetByName(SHEET_NAME);
  const data   = sheet.getDataRange().getValues();
  const result = [];
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    if (!row[0]) continue;
    result.push({
      id:      i + 1,
      date:    row[0] ? Utilities.formatDate(new Date(row[0]), 'Asia/Kolkata', 'dd/MM/yyyy') : '',
      category:row[1] || '',
      desc:    row[2] || '',
      type:    row[3] || '',
      amount:  parseFloat(row[4]) || 0,
      mode:    row[5] || '',
      month:   row[6] || '',
      year:    row[7] || ''
    });
  }
  return result;
}

// ── Read Debts ───────────────────────────────────────────────
function getDebts(ss) {
  const sheet  = ss.getSheetByName(DEBT_SHEET);
  const data   = sheet.getDataRange().getValues();
  const result = [];
  for (let i = 2; i < data.length; i++) {
    const row = data[i];
    if (!row[1] || row[1] === 'Total Outstanding') continue;
    result.push({
      id:          i + 1,
      lender:      row[0] || '',
      principal:   parseFloat(row[1]) || 0,
      interestRate:parseFloat(row[2]) || 0,
      emi:         parseFloat(row[3]) || 0,
      outstanding: parseFloat(row[4]) || 0,
      startDate:   row[5] ? Utilities.formatDate(new Date(row[5]), 'Asia/Kolkata', 'dd/MM/yyyy') : '',
      nextDue:     row[6] ? Utilities.formatDate(new Date(row[6]), 'Asia/Kolkata', 'dd/MM/yyyy') : '',
      status:      row[7] || 'Active',
      notes:       row[8] || ''
    });
  }
  return result;
}

// ── Save Entry ───────────────────────────────────────────────
function saveEntry(ss, data) {
  const sheet    = ss.getSheetByName(SHEET_NAME);
  const lastRow  = sheet.getLastRow() + 1;
  const dateVal  = new Date(data.date);
  sheet.getRange(lastRow, 1).setValue(dateVal).setNumberFormat('dd/MM/yyyy');
  sheet.getRange(lastRow, 2).setValue(data.category);
  sheet.getRange(lastRow, 3).setValue(data.desc || '');
  sheet.getRange(lastRow, 4).setValue(data.type);
  sheet.getRange(lastRow, 5).setValue(parseFloat(data.amount)).setNumberFormat('₹#,##0.00');
  sheet.getRange(lastRow, 6).setValue(data.mode);
}

// ── Save Debt ────────────────────────────────────────────────
function saveDebt(ss, data) {
  const sheet   = ss.getSheetByName(DEBT_SHEET);
  const lastRow = Math.max(sheet.getLastRow() + 1, 3);
  sheet.getRange(lastRow, 1).setValue(data.lender || '');
  sheet.getRange(lastRow, 2).setValue(parseFloat(data.principal) || 0).setNumberFormat('₹#,##0');
  sheet.getRange(lastRow, 3).setValue(parseFloat(data.interestRate) || 0);
  sheet.getRange(lastRow, 4).setValue(parseFloat(data.emi) || 0).setNumberFormat('₹#,##0');
  sheet.getRange(lastRow, 5).setValue(parseFloat(data.outstanding) || 0).setNumberFormat('₹#,##0');
  if (data.startDate) sheet.getRange(lastRow, 6).setValue(new Date(data.startDate)).setNumberFormat('dd/MM/yyyy');
  if (data.nextDue)   sheet.getRange(lastRow, 7).setValue(new Date(data.nextDue)).setNumberFormat('dd/MM/yyyy');
  sheet.getRange(lastRow, 8).setValue(data.status || 'Active');
  sheet.getRange(lastRow, 9).setValue(data.notes || '');
}

// ── Update Debt Status ───────────────────────────────────────
function updateDebtStatus(ss, data) {
  const sheet = ss.getSheetByName(DEBT_SHEET);
  sheet.getRange(data.id, 8).setValue(data.status);
}

// ── Delete Entry ─────────────────────────────────────────────
function deleteEntry(ss, data) {
  const sheet = ss.getSheetByName(SHEET_NAME);
  sheet.deleteRow(data.id);
}

// ── Monthly Summary ──────────────────────────────────────────
function getMonthlySummary(entries) {
  const map = {};
  entries.forEach(e => {
    if (!e.month) return;
    if (!map[e.month]) map[e.month] = { month: e.month, income: 0, expense: 0, count: 0 };
    if (e.type === 'Income')  map[e.month].income  += e.amount;
    if (e.type === 'Expense') map[e.month].expense += e.amount;
    map[e.month].count++;
  });
  const order = ['Jun 2025','Jul 2025','Aug 2025','Sep 2025','Oct 2025',
                 'Nov 2025','Dec 2025','Jan 2026','Feb 2026','Mar 2026',
                 'Apr 2026','May 2026','Jun 2026'];
  return order.filter(m => map[m]).map(m => ({
    ...map[m],
    savings: map[m].income - map[m].expense,
    rate: map[m].income > 0 ? Math.round((map[m].income - map[m].expense) / map[m].income * 100) : 0
  }));
}

// ── Category Summary ─────────────────────────────────────────
function getCategorySummary(entries) {
  const map = {};
  const groups = {
    'Food':'Personal','Diesel / Fuel':'Personal','Rent (Room)':'Personal',
    'Home':'Personal','Medical':'Personal','Luxury':'Personal',
    'Car Maintenance':'Personal','With Friends':'Personal',
    'Investment':'Personal','Others':'Personal',
    'Marketing':'Business','Logistics':'Business','Compliance':'Business',
    'Office Expenses':'Business','Office Rent':'Business',
    'Godown Rent':'Business','Salary':'Business',
    'Networking':'Business','Growth':'Business'
  };
  entries.filter(e => e.type === 'Expense').forEach(e => {
    if (!map[e.category]) map[e.category] = { category: e.category, group: groups[e.category] || 'Personal', total: 0 };
    map[e.category].total += e.amount;
  });
  return Object.values(map).sort((a, b) => b.total - a.total);
}
