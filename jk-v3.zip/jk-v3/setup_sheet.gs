// ============================================================
// JK MONEY TRACKER — Sheet Setup Script
// Run this ONCE in Google Apps Script:
//   Extensions → Apps Script → paste this → Run → Done
// ============================================================

function setupJKMoneyTracker() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // ── COLORS ──────────────────────────────────────────────
  const TEAL       = '#1a6b7a';
  const TEAL_LIGHT = '#e8f4f6';
  const TEAL_MID   = '#b2d8de';
  const GREEN      = '#4a7c2f';
  const GREEN_LT   = '#eaf3e0';
  const RED        = '#c0392b';
  const RED_LT     = '#fdecea';
  const WHITE      = '#ffffff';
  const GRAY1      = '#f7f9f9';
  const GRAY2      = '#dde6e8';
  const GRAY3      = '#8a9b9e';
  const AMBER      = '#e67e22';
  const AMBER_LT   = '#fef5e7';

  const CATEGORIES = [
    'Food','Diesel / Fuel','Rent (Room)','Home','Medical',
    'Luxury','Car Maintenance','With Friends','Investment','Others',
    'Marketing','Logistics','Compliance','Office Expenses',
    'Office Rent','Godown Rent','Salary','Networking','Growth'
  ];
  const TYPES  = ['Expense','Income'];
  const MODES  = ['Cash','UPI','Online'];
  const STATUS = ['Active','Paid','Overdue'];

  // ── HELPERS ─────────────────────────────────────────────
  function getOrCreate(name) {
    return ss.getSheetByName(name) || ss.insertSheet(name);
  }

  function styleHeader(sheet, row, cols, bg, fg) {
    const r = sheet.getRange(row, 1, 1, cols);
    r.setBackground(bg).setFontColor(fg).setFontWeight('bold')
     .setFontSize(11).setVerticalAlignment('middle')
     .setHorizontalAlignment('center');
    sheet.setRowHeight(row, 36);
  }

  function addDropdown(sheet, row, col, numRows, values) {
    const rule = SpreadsheetApp.newDataValidation()
      .requireValueInList(values, true).setAllowInvalid(false).build();
    sheet.getRange(row, col, numRows, 1).setDataValidation(rule);
  }

  function setTabColor(sheet, color) {
    sheet.setTabColor(color);
  }

  // ── 1. ENTRIES TAB ──────────────────────────────────────
  const entSheet = getOrCreate('Entries');
  entSheet.clearContents();
  entSheet.clearFormats();
  setTabColor(entSheet, TEAL);

  const entHeaders = ['Date','Category','Description','Type','Amount (₹)','Payment Mode','Month','Year'];
  entSheet.getRange(1, 1, 1, entHeaders.length).setValues([entHeaders]);
  styleHeader(entSheet, 1, entHeaders.length, TEAL, WHITE);

  entSheet.setColumnWidth(1, 110);
  entSheet.setColumnWidth(2, 160);
  entSheet.setColumnWidth(3, 220);
  entSheet.setColumnWidth(4, 100);
  entSheet.setColumnWidth(5, 120);
  entSheet.setColumnWidth(6, 130);
  entSheet.setColumnWidth(7, 90);
  entSheet.setColumnWidth(8, 70);

  // Auto Month/Year formulas for rows 2–1000
  for (let i = 2; i <= 1000; i++) {
    entSheet.getRange(i, 7).setFormula(`=IF(A${i}="","",TEXT(A${i},"MMM YYYY"))`);
    entSheet.getRange(i, 8).setFormula(`=IF(A${i}="","",YEAR(A${i}))`);
  }

  // Dropdowns
  addDropdown(entSheet, 2, 2, 999, CATEGORIES);
  addDropdown(entSheet, 2, 4, 999, TYPES);
  addDropdown(entSheet, 2, 6, 999, MODES);

  // Freeze header
  entSheet.setFrozenRows(1);

  // Alternating row colors via conditional formatting
  const incomeRule = SpreadsheetApp.newConditionalFormatRule()
    .whenFormulaSatisfied('=$D2="Income"')
    .setBackground(GREEN_LT).setRanges([entSheet.getRange('A2:F1000')]).build();
  const expRule = SpreadsheetApp.newConditionalFormatRule()
    .whenFormulaSatisfied('=$D2="Expense"')
    .setBackground(RED_LT).setRanges([entSheet.getRange('A2:F1000')]).build();
  entSheet.setConditionalFormatRules([incomeRule, expRule]);

  entSheet.getRange('E2:E1000').setNumberFormat('₹#,##0.00');
  entSheet.getRange('A2:A1000').setNumberFormat('dd/MM/yyyy');

  // ── 2. MONTHLY SUMMARY TAB ──────────────────────────────
  const sumSheet = getOrCreate('Monthly Summary');
  sumSheet.clearContents();
  sumSheet.clearFormats();
  setTabColor(sumSheet, GREEN);

  const months = ['Jun 2025','Jul 2025','Aug 2025','Sep 2025','Oct 2025',
                  'Nov 2025','Dec 2025','Jan 2026','Feb 2026','Mar 2026',
                  'Apr 2026','May 2026','Jun 2026'];

  // Title
  sumSheet.getRange('A1').setValue('JK MONEY TRACKER — Monthly Summary');
  sumSheet.getRange('A1:F1').merge()
    .setBackground(TEAL).setFontColor(WHITE).setFontWeight('bold')
    .setFontSize(14).setHorizontalAlignment('center').setVerticalAlignment('middle');
  sumSheet.setRowHeight(1, 44);

  // Headers
  const sumHdrs = ['Month','Total Income (₹)','Total Expense (₹)','Net Savings (₹)','Savings Rate %','Transactions'];
  sumSheet.getRange(2, 1, 1, sumHdrs.length).setValues([sumHdrs]);
  styleHeader(sumSheet, 2, sumHdrs.length, TEAL_MID, TEAL);

  // Month rows with SUMIF formulas
  months.forEach((m, i) => {
    const r = i + 3;
    sumSheet.getRange(r, 1).setValue(m);
    sumSheet.getRange(r, 2).setFormula(`=SUMIFS(Entries!E:E,Entries!G:G,"${m}",Entries!D:D,"Income")`);
    sumSheet.getRange(r, 3).setFormula(`=SUMIFS(Entries!E:E,Entries!G:G,"${m}",Entries!D:D,"Expense")`);
    sumSheet.getRange(r, 4).setFormula(`=B${r}-C${r}`);
    sumSheet.getRange(r, 5).setFormula(`=IF(B${r}=0,0,ROUND((D${r}/B${r})*100,1))`);
    sumSheet.getRange(r, 6).setFormula(`=COUNTIF(Entries!G:G,"${m}")`);
    sumSheet.getRange(r, 4).setBackground(GRAY1);
  });

  // Totals row
  const lastR = months.length + 3;
  sumSheet.getRange(lastR, 1).setValue('TOTAL');
  sumSheet.getRange(lastR, 2).setFormula(`=SUM(B3:B${lastR-1})`);
  sumSheet.getRange(lastR, 3).setFormula(`=SUM(C3:C${lastR-1})`);
  sumSheet.getRange(lastR, 4).setFormula(`=B${lastR}-C${lastR}`);
  sumSheet.getRange(lastR, 5).setFormula(`=IF(B${lastR}=0,0,ROUND((D${lastR}/B${lastR})*100,1))`);
  sumSheet.getRange(lastR, 6).setFormula(`=SUM(F3:F${lastR-1})`);
  sumSheet.getRange(lastR, 1, 1, 6).setBackground(TEAL).setFontColor(WHITE).setFontWeight('bold');

  // Formatting
  sumSheet.getRange(3, 2, months.length+1, 3).setNumberFormat('₹#,##0');
  sumSheet.getRange(3, 5, months.length+1, 1).setNumberFormat('0.0"%"');
  [2,3,4,5].forEach(c => sumSheet.setColumnWidth(c, 150));
  sumSheet.setColumnWidth(1, 120);
  sumSheet.setFrozenRows(2);

  // Net savings conditional formatting
  const posRule = SpreadsheetApp.newConditionalFormatRule()
    .whenNumberGreaterThan(0).setBackground(GREEN_LT).setFontColor(GREEN)
    .setRanges([sumSheet.getRange(`D3:D${lastR-1}`)]).build();
  const negRule = SpreadsheetApp.newConditionalFormatRule()
    .whenNumberLessThan(0).setBackground(RED_LT).setFontColor(RED)
    .setRanges([sumSheet.getRange(`D3:D${lastR-1}`)]).build();
  sumSheet.setConditionalFormatRules([posRule, negRule]);

  // ── 3. DEBT TRACKER TAB ─────────────────────────────────
  const debtSheet = getOrCreate('Debt Tracker');
  debtSheet.clearContents();
  debtSheet.clearFormats();
  setTabColor(debtSheet, AMBER);

  // Title
  debtSheet.getRange('A1').setValue('JK MONEY TRACKER — Debt & Loan Tracker');
  debtSheet.getRange('A1:I1').merge()
    .setBackground(AMBER).setFontColor(WHITE).setFontWeight('bold')
    .setFontSize(14).setHorizontalAlignment('center').setVerticalAlignment('middle');
  debtSheet.setRowHeight(1, 44);

  const debtHdrs = ['Lender','Principal (₹)','Interest Rate %','EMI (₹)','Outstanding (₹)','Start Date','Next Due Date','Status','Notes'];
  debtSheet.getRange(2, 1, 1, debtHdrs.length).setValues([debtHdrs]);
  styleHeader(debtSheet, 2, debtHdrs.length, AMBER, WHITE);

  addDropdown(debtSheet, 3, 8, 97, STATUS);

  // Status conditional formatting
  const activeRule = SpreadsheetApp.newConditionalFormatRule()
    .whenTextEqualTo('Active').setBackground(TEAL_LIGHT).setFontColor(TEAL)
    .setRanges([debtSheet.getRange('H3:H100')]).build();
  const paidRule = SpreadsheetApp.newConditionalFormatRule()
    .whenTextEqualTo('Paid').setBackground(GREEN_LT).setFontColor(GREEN)
    .setRanges([debtSheet.getRange('H3:H100')]).build();
  const overdueRule = SpreadsheetApp.newConditionalFormatRule()
    .whenTextEqualTo('Overdue').setBackground(RED_LT).setFontColor(RED)
    .setRanges([debtSheet.getRange('H3:H100')]).build();
  debtSheet.setConditionalFormatRules([activeRule, paidRule, overdueRule]);

  debtSheet.getRange('B3:E100').setNumberFormat('₹#,##0');
  debtSheet.getRange('F3:G100').setNumberFormat('dd/MM/yyyy');
  [1,9].forEach(c => debtSheet.setColumnWidth(c, 160));
  [2,4,5].forEach(c => debtSheet.setColumnWidth(c, 130));
  debtSheet.setColumnWidth(3, 120);
  debtSheet.setColumnWidth(6, 110);
  debtSheet.setColumnWidth(7, 110);
  debtSheet.setColumnWidth(8, 100);

  // Summary row
  debtSheet.getRange('A102').setValue('Total Outstanding');
  debtSheet.getRange('E102').setFormula('=SUMIF(H3:H100,"Active",E3:E100)');
  debtSheet.getRange('A102:I102').setBackground(AMBER_LT).setFontWeight('bold');
  debtSheet.setFrozenRows(2);

  // ── 4. CATEGORY SUMMARY TAB ─────────────────────────────
  const catSheet = getOrCreate('Category Summary');
  catSheet.clearContents();
  catSheet.clearFormats();
  setTabColor(catSheet, TEAL_MID);

  catSheet.getRange('A1').setValue('JK MONEY TRACKER — Category Summary');
  catSheet.getRange('A1:D1').merge()
    .setBackground(TEAL).setFontColor(WHITE).setFontWeight('bold')
    .setFontSize(14).setHorizontalAlignment('center').setVerticalAlignment('middle');
  catSheet.setRowHeight(1, 44);

  const catHdrs = ['Category','Group','Total Spent (₹)','% of Expenses'];
  catSheet.getRange(2, 1, 1, catHdrs.length).setValues([catHdrs]);
  styleHeader(catSheet, 2, catHdrs.length, TEAL_MID, TEAL);

  const catGroups = [
    ['Food','Personal'],['Diesel / Fuel','Personal'],['Rent (Room)','Personal'],
    ['Home','Personal'],['Medical','Personal'],['Luxury','Personal'],
    ['Car Maintenance','Personal'],['With Friends','Personal'],
    ['Investment','Personal'],['Others','Personal'],
    ['Marketing','Business'],['Logistics','Business'],['Compliance','Business'],
    ['Office Expenses','Business'],['Office Rent','Business'],
    ['Godown Rent','Business'],['Salary','Business'],
    ['Networking','Business'],['Growth','Business']
  ];

  catGroups.forEach(([cat, grp], i) => {
    const r = i + 3;
    catSheet.getRange(r, 1).setValue(cat);
    catSheet.getRange(r, 2).setValue(grp);
    catSheet.getRange(r, 3).setFormula(`=SUMIFS(Entries!E:E,Entries!B:B,"${cat}",Entries!D:D,"Expense")`);
    catSheet.getRange(r, 4).setFormula(`=IF(SUM(C3:C21)=0,0,ROUND(C${r}/SUM(C$3:C$21)*100,1))`);
  });

  catSheet.getRange('C3:C21').setNumberFormat('₹#,##0');
  catSheet.getRange('D3:D21').setNumberFormat('0.0"%"');
  catSheet.setColumnWidth(1, 160);
  catSheet.setColumnWidth(2, 100);
  catSheet.setColumnWidth(3, 150);
  catSheet.setColumnWidth(4, 130);

  const bizRule = SpreadsheetApp.newConditionalFormatRule()
    .whenTextEqualTo('Business').setBackground(TEAL_LIGHT).setFontColor(TEAL)
    .setRanges([catSheet.getRange('B3:B21')]).build();
  const perRule = SpreadsheetApp.newConditionalFormatRule()
    .whenTextEqualTo('Personal').setBackground(GREEN_LT).setFontColor(GREEN)
    .setRanges([catSheet.getRange('B3:B21')]).build();
  catSheet.setConditionalFormatRules([bizRule, perRule]);
  catSheet.setFrozenRows(2);

  // ── REORDER TABS ────────────────────────────────────────
  ss.setActiveSheet(entSheet);
  ss.moveActiveSheet(1);
  ss.setActiveSheet(sumSheet);
  ss.moveActiveSheet(2);
  ss.setActiveSheet(catSheet);
  ss.moveActiveSheet(3);
  ss.setActiveSheet(debtSheet);
  ss.moveActiveSheet(4);

  SpreadsheetApp.getUi().alert(
    '✅ JK Money Tracker Setup Complete!\n\n' +
    '4 tabs created:\n' +
    '• Entries — your daily transaction log\n' +
    '• Monthly Summary — auto charts & totals\n' +
    '• Category Summary — breakdown by category\n' +
    '• Debt Tracker — loans & EMI tracker\n\n' +
    'Now deploy web_app.gs as a Web App and paste the URL into index.html'
  );
}
